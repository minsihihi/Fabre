const EventEmitter = require("events");

const eventEmitter = new EventEmitter();

module.exports = eventEmitter;